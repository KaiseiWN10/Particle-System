#include <gtest/gtest.h>

TEST(Particle,ctor)
{
  ASSERT_TRUE(1==0);
}